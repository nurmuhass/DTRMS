# Daily Task Reporting and Management System

DTRMS is an internal institutional application. It includes role-based access, HR organization management, daily reporting, and sequential supervisor and HR approval.

MySQL is the system of record. Daily reporting, approvals, reminders and exports operate without Google Forms or Google Sheets.

## Release documentation

- [Internal installation](INSTALLATION.md) and [database documentation](DATABASE_DOCUMENTATION.md)
- [User guide](USER_GUIDE.md), [HR administrator guide](HR_ADMIN_GUIDE.md) and [system administrator guide](SYSTEM_ADMIN_GUIDE.md)
- [Backup and recovery](BACKUP_AND_RECOVERY.md), [security audit](SECURITY_REPORT.md) and [testing results](TESTING_REPORT.md)
- [November 2026 system audit](docs/system-audit.md)
- [Technical maintenance and handover](MAINTENANCE.md)
- [Staff work schedules](docs/staff-work-schedules.md)
- [Flexible weekly scheduling and Sunday deadlines](docs/flexible-weekly-scheduling.md)
- [Staff leave and submission exemptions](docs/staff-leave.md)
- [Staff Submission Monitoring](docs/submission-monitoring.md)
- [Individual weekly and monthly staff records](docs/individual-staff-records.md)

## Requirements

- PHP 8.2 or later for the web server and CLI, with PDO, `pdo_mysql`, and `mbstring` enabled.
- MySQL 8 with an empty database and an account permitted to run migrations. XAMPP commonly bundles MariaDB, so check the database server you are connecting to.
- Composer 2 and the PHP extensions required by PHPMailer, Dompdf, and PhpSpreadsheet. Run `composer check-platform-reqs` after installation.
- Writable `storage/logs/` and `storage/sessions/` directories for the applicable PHP processes.

## Install and run locally

Follow the [installation guide](docs/installation.md) to provision MySQL, apply migrations and seeds, create the first administrator, and launch the local server. The guide also covers helpdesk recovery and the authentication integration suite.

Follow the [HR management guide](docs/hr-management.md) for the Phase 3 upgrade, database grants, department and staff administration, and Excel import.

Follow the [staff reporting guide](docs/staff-reporting.md) for the Phase 4 upgrade, report lifecycle, database grants, and scheduling exceptions.

Follow the [supervisor approval guide](docs/supervisor-approval.md) for the Phase 5 upgrade, approval workflow, and notification access.

Follow the [HR final approval guide](docs/hr-final-approval.md) for the Phase 6 upgrade, report permissions, and sequential review workflow.

Follow the [system administration guide](docs/system-administration.md) for the Phase 7 upgrade, technical settings, monitoring, and deployment scheduler integration.

Follow the [notification and reminder guide](docs/notifications.md) for the Phase 8 upgrade, SMTP configuration, and scheduler command.

Follow the [reporting and exports guide](docs/reporting-and-exports.md) for Phase 9 analytics, reporting permissions, monthly metrics, and PDF and Excel downloads.

Process environment variables take precedence over the optional local `.env` file, which uses PHP INI syntax. Supply values containing special INI characters through the process environment.

## Run on intranet Apache

Use a dedicated virtual host with its document root set to the project’s `public/` directory. Enable `mod_rewrite`; allow `AuthConfig FileInfo Indexes` overrides for the public directory or put the equivalent access and rewrite rules in the virtual host. Disable directory listing and MultiViews in the virtual host. Serve intranet traffic over HTTPS.

If the checkout sits under a broader document root such as XAMPP's `htdocs`, block access to the checkout through that parent site as well. The root `.htaccess` provides a deny rule when Apache honors authorization overrides. Verify the parent site cannot serve `.env`, migration files, or logs. Keep the logs, configuration, and Composer dependencies outside the public directory.

See [the development architecture](docs/architecture.md) for request flow, migration conventions, and the role matrix.
